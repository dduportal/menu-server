package com.cicdlectures.menuserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenuServerApplication {

  public static void main(String[] args) {
    SpringApplication.run(MenuServerApplication.class, args);
  }

}
